import React from 'react';
import "./Contact.css"

export default function Contact() {
    return (
        <>
            <div className="custom__container" id="container__id">
                <div className="container" id="container__contact">
                    <div className="row pt-5" id="contact__row">
                        <div className="col-lg-5 col-md-5 col-sm-5 text-light" id="contact__info">
                            <h1 className="contact__header"> My Contact </h1>
                            <p> You can contact me and access my services on below mentioned information.
                                Or you can fill the contact form on right. :)
                            </p>

                            <h1 className="contact__label"> Address </h1>
                            <p> Ward 10, 14 Bigha, Rishikesh, Uttrakhand</p>

                            <h1 className="contact__label"> Phone </h1>
                            <p> 08273119969</p>

                            <h1 className="contact__label"> Email </h1>
                            <p> rohiitnegii@gmail.com</p>
                        </div>

                        <div className="col-lg-5 col-md-5 col-sm-5 text-light">
                            <h1 className="contact__head"> Quick Contact Form </h1>
                            <div id="contact__form">
                                <div  className="form-group" id="half__col">
                                    <input className="col-xs-6 bg-dark" type="text" name="name" placeholder="Your Name" />
                                    <input className="col-xs-6 bg-dark" type="email" name="email" placeholder="Your Email" />
                                    <input className="col-xs-6 bg-dark" type="phone" name="phone" placeholder="Your Phone" />
                                    <input className="col-xs-6 bg-dark" type="address" name="address" placeholder="Address" />
                                    <textarea className="bg-dark" type="message" name="message" placeholder="Your Message..." />
                                </div>

                                <div className="contact__btn">
                                    <button className="btn">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
};